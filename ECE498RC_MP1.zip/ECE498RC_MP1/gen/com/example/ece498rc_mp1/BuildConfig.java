/** Automatically generated file. DO NOT MODIFY */
package com.example.ece498rc_mp1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}